/*
  This file is part of Designar.
  Copyright (C) 2017 by Alejandro J. Mujica

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.

  Any user request of this software, write to 

  Alejandro Mujica

  aledrums@gmail.com
*/

# include <hash.H>

namespace Designar
{

  nat_t super_fast_hash(void * key, nat_t len)
  {
    const unsigned char * data = reinterpret_cast<unsigned char *>(key);
    
    nat_t hash = len, tmp;
    
    int rem;
    
    if (len <= 0 or data == nullptr)
      return 0;
    
    rem = len & 3;
    len >>= 2;
    
    for ( ; len > 0; --len)
      {
	hash += get16bits(data);
	tmp   = (get16bits(data + 2) << 11) ^ hash;
	hash  = (hash << 16) ^ tmp;
	data += 2 * sizeof(uint16_t);
	hash += hash >> 11;
      }
    
    switch (rem) 
      {
      case 3: 
	hash += get16bits (data);
	hash ^= hash << 16;
	hash ^= ((signed char)data[sizeof (uint16_t)]) << 18;
	hash += hash >> 11;
	break;
      case 2: 
	hash += get16bits (data);
	hash ^= hash << 11;
	hash += hash >> 17;
	break;
      case 1: 
	hash += (signed char)*data;
	hash ^= hash << 10;
	hash += hash >> 1;
      }
    
    /* Force "avalanching" of final 127 bits */
    hash ^= hash << 3;
    hash += hash >> 5;
    hash ^= hash << 4;
    hash += hash >> 17;
    hash ^= hash << 25;
    hash += hash >> 6;
    
    return hash;
  }

} // end namespace Designar
